export class MovieModel
{
    movieId : number;
    language : string;
    title : string;
    location : string;
    plot : string;
    poster : string;
    listingType : string;
    imdbRating: string;
    imdbID : string;
    soundEffects: string[];
    stills: string[];
}