﻿using BookMyMovie.Contracts;
using BookMyMovie.Models;
using System;
using System.Collections.Generic;
using System.Text;

namespace BookMyMovie
{
    public class MovieMappingConfiguration : AutoMapper.Profile
    {
        public MovieMappingConfiguration()
        {
            CreateMap<MovieModel, MovieResponse>();
            CreateMap<MovieModel, MovieGridResponse>();
        }
    }
}
