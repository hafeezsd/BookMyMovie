using System;
using System.IO;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using BookMyMovie.ServiceInterface;
using System.Net.Http;
using BookMyMovie.Contracts;
using System.Net;
using System.Text;
using System.Collections.Generic;
using Newtonsoft.Json.Serialization;

namespace BookMyMovie
{
    public class BookMyMovieFunction
    {
        JsonSerializerSettings JsonSerializerSettings = new JsonSerializerSettings
        {
            ContractResolver = new CamelCasePropertyNamesContractResolver(),
            Formatting = Formatting.Indented,
            //DateFormatString = "yyyy-MM-ddTHH:mmZ",
            NullValueHandling = NullValueHandling.Include
        };

        #region PRIVATE VARIABLES 

        /// <summary>
        /// movies service
        /// </summary>
        private readonly IBookMyMovieService _bookMyMovieService;

        #endregion

        #region CONSTRUCTOR

        public BookMyMovieFunction(IBookMyMovieService BookMyMovieService)
        {
            _bookMyMovieService = BookMyMovieService;
        }

        #endregion

        #region movieS - CRUD FUNCTIONS

        #region Endpoint - /GetAllMovies

        /// <summary>
        /// This Azure function - is used to retrieve all movies
        /// </summary>
        /// <param name="req"></param>
        /// <returns>List of moviess</returns>
        [FunctionName("GetAllMovies")]
        public async Task<HttpResponseMessage> GetAllMovies(
        [HttpTrigger(AuthorizationLevel.Anonymous, "POST", Route = "GetAllMovies")] HttpRequest req)
        {
            List<MovieGridResponse> response = new List<MovieGridResponse>();

            HttpResponseMessage httpResponse = new HttpResponseMessage();

            try
            {
                string requestBody = await Task.Run(() => { return new StreamReader(req.Body).ReadToEndAsync(); }).ConfigureAwait(true);
                SearchRequest request = JsonConvert.DeserializeObject<SearchRequest>(requestBody);

                if (request == null) // Check for Bad request
                {
                    httpResponse.StatusCode = HttpStatusCode.BadRequest;
                }
                else
                {
                    // Service method is called to retrieve all movies
                    response = await _bookMyMovieService.GetAllMovies(request).ConfigureAwait(true);
                }                

                httpResponse.StatusCode = HttpStatusCode.OK;
                httpResponse.Content = new StringContent(JsonConvert.SerializeObject(response, JsonSerializerSettings), Encoding.UTF8, "application/json");
            }            
            catch (Exception ex)
            {
                httpResponse.StatusCode = HttpStatusCode.InternalServerError;                
            }

            return httpResponse;
        }

        #endregion        

        #region Endpoint - /GetMovieDetailsById

        /// <summary>
        /// This Azure function - is used to return the movie Information
        /// </summary>
        /// <param name="req"></param>
        /// <param name="movieId">Movie Id</param>
        /// <returns>movies Information</returns>        
        [FunctionName("GetMovieDetailsById")]        
        public async Task<HttpResponseMessage> GetMovieDetailsById(
        [HttpTrigger(AuthorizationLevel.Function, "GET", Route = "GetMovieDetailsById/{movieId}")] HttpRequest req, int movieId)
        {
            MovieResponse response = null;
            HttpResponseMessage httpResponse = new HttpResponseMessage();
            try
            {
                if (movieId <= 0) // Check for Bad request
                {
                    httpResponse.StatusCode = HttpStatusCode.BadRequest;
                }
                else
                {
                    // service method is called to retrieve movies information
                    response = await _bookMyMovieService.GetMovieDetailsById(movieId).ConfigureAwait(true);

                    httpResponse.StatusCode = HttpStatusCode.OK;
                    httpResponse.Content = new StringContent(JsonConvert.SerializeObject(response, JsonSerializerSettings), Encoding.UTF8, "application/json");
                }                
            }            
            catch (Exception)
            {

                httpResponse.StatusCode = HttpStatusCode.InternalServerError;
            }

            return httpResponse;
        }

        #endregion

        #region Endpoint - /GetAllMovieLanguages

        /// <summary>
        /// This Azure function - is used to return movie languages
        /// </summary>
        /// <param name="req"></param>
        /// <returns>movies Information</returns>        
        [FunctionName("GetAllMovieLanguages")]
        public async Task<HttpResponseMessage> GetAllMovieLanguages(
        [HttpTrigger(AuthorizationLevel.Function, "GET", Route = "GetAllMovieLanguages")] HttpRequest req)
        {
            List<string> response = null;
            HttpResponseMessage httpResponse = new HttpResponseMessage();
            try
            {
                // service method is called to retrieve languages information
                response = await _bookMyMovieService.GetAllMovieLanguages().ConfigureAwait(true);
                httpResponse.StatusCode = HttpStatusCode.OK;
                httpResponse.Content = new StringContent(JsonConvert.SerializeObject(response, JsonSerializerSettings), Encoding.UTF8, "application/json");
            }
            catch (Exception)
            {

                httpResponse.StatusCode = HttpStatusCode.InternalServerError;
            }

            return httpResponse;
        }

        #endregion

        #region Endpoint - /GetAllMovieLocations

        /// <summary>
        /// This Azure function - is used to return movie locations
        /// </summary>
        /// <param name="req"></param>
        /// <returns>movies Information</returns>        
        [FunctionName("GetAllMovieLocations")]
        public async Task<HttpResponseMessage> GetAllMovieLocations(
        [HttpTrigger(AuthorizationLevel.Function, "GET", Route = "GetAllMovieLocations")] HttpRequest req)
        {
            List<string> response = null;
            HttpResponseMessage httpResponse = new HttpResponseMessage();
            try
            {
                // service method is called to retrieve languages information
                response = await _bookMyMovieService.GetAllMovieLocations().ConfigureAwait(true);
                httpResponse.StatusCode = HttpStatusCode.OK;
                httpResponse.Content = new StringContent(JsonConvert.SerializeObject(response, JsonSerializerSettings), Encoding.UTF8, "application/json");
            }
            catch (Exception)
            {

                httpResponse.StatusCode = HttpStatusCode.InternalServerError;
            }

            return httpResponse;
        }

        #endregion

        #endregion
    }
}
