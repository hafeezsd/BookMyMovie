﻿namespace BookMyMovie
{
    internal class VendorModelMappingConfiguration
    {
    }
}