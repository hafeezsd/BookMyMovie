﻿using AutoMapper;
using Microsoft.Azure.Functions.Extensions.DependencyInjection;
using Microsoft.Extensions.DependencyInjection;
using BookMyMovie.DA;
using BookMyMovie.DAInterface;
using BookMyMovie.Service;
using BookMyMovie.ServiceInterface;
using System;

[assembly: FunctionsStartup(typeof(BookMyMovie.Startup))]
namespace BookMyMovie
{
    public class Startup : FunctionsStartup
    {
        public override void Configure(IFunctionsHostBuilder builder)
        {
            if (builder == null)
                throw new ArgumentNullException(null, new Exception());
            ConfigureServices(builder.Services).BuildServiceProvider(true);
        }

        public static IServiceCollection ConfigureServices(IServiceCollection services)
        {
            #region Mapper Config

            services.AddAutoMapper(typeof(MovieMappingConfiguration));

            #endregion

            services.AddScoped<IBookMyMovieService, BookMyMovieService>();
            services.AddScoped<IBookMyMovieRepository, BookMyMovieRepository>();

            #region Cors

            services.AddCors(options =>
            {
                options.AddPolicy("AllowAll",
                       builder =>
                       {
                           builder
                           .AllowAnyOrigin()
                           .AllowAnyMethod()
                           .AllowAnyHeader()
                           .AllowCredentials();
                       });
            });

            #endregion

            return services;
        }
    }
}
