﻿using BookMyMovie.Models;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace BookMyMovie.DAInterface
{
    public interface IBookMyMovieRepository
    {
        /// <summary>
        /// This repository method - is used to retrieve all moview
        /// </summary>
        /// <param name="searchString"></param>
        /// <param name="language"></param>
        /// <param name="location"></param>
        /// <returns></returns>
        Task<List<MovieModel>> GetAllMovies(string searchString, string location, string language);

        /// <summary>
        /// This repository method - is used to retrieve movie details by movie Id 
        /// </summary>
        /// <param name="movieId"></param>
        /// <returns></returns>
        Task<MovieModel> GetMovieDetailsById(int movieId);

        /// <summary>
        /// This repository method - is used to retrieve movie languages
        /// </summary>
        /// <returns></returns>
        Task<List<string>> GetAllMovieLanguages();

        /// <summary>
        /// This repository method - is used to retrieve movie locations
        /// </summary>
        /// <returns></returns>
        Task<List<string>> GetAllMovieLocations();
    }
}
