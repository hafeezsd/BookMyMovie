﻿using AutoMapper;
using BookMyMovie.Contracts;
using BookMyMovie.DAInterface;
using BookMyMovie.Models;
using BookMyMovie.ServiceInterface;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace BookMyMovie.Service
{
    public class BookMyMovieService : IBookMyMovieService
    {
        #region PRIVATE VARIABLES       

        private readonly IMapper _mapper;
        private readonly IBookMyMovieRepository _movieRepository;

        #endregion

        #region CONSTRUCTOR

        public BookMyMovieService(IMapper mapper, IBookMyMovieRepository movieRepository)
        {
            _mapper = mapper;
            _movieRepository = movieRepository;
        }

        #endregion

        /// <summary>
        /// This service method - is used to retrieve all movies
        /// </summary>
        /// <param name="searchCriteria"></param>
        /// <returns></returns>
        public async Task<List<MovieGridResponse>> GetAllMovies(SearchRequest searchCriteria)
        {
            List<MovieModel> movies = await _movieRepository.GetAllMovies(searchCriteria.SearchString?.Trim().ToLower(), searchCriteria.Location?.Trim().ToLower(),
                                                                          searchCriteria.Location?.Trim().ToLower());
            return _mapper.Map<List<MovieGridResponse>>(movies);
        }

        /// <summary>
        /// This service method - is used to retrieve movie details by movie Id 
        /// </summary>
        /// <param name="movieId"></param>
        /// <returns></returns>
        public async Task<MovieResponse> GetMovieDetailsById(int movieId)
        {
            MovieModel movie = await _movieRepository.GetMovieDetailsById(movieId);
            return _mapper.Map<MovieResponse>(movie);
        }

        /// <summary>
        /// This service method - is used to retrieve movie languages
        /// </summary>
        /// <returns></returns>
        public async Task<List<string>> GetAllMovieLanguages()
        {
            return await _movieRepository.GetAllMovieLanguages();
        }

        /// <summary>
        /// This service method - is used to retrieve movie locations
        /// </summary>
        /// <returns></returns>
        public async Task<List<string>> GetAllMovieLocations()
        {
            return await _movieRepository.GetAllMovieLocations();
        }
    }
}
