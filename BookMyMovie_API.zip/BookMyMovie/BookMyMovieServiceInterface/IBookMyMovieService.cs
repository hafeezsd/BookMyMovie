﻿using BookMyMovie.Contracts;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace BookMyMovie.ServiceInterface
{
    public interface IBookMyMovieService
    {
        /// <summary>
        /// This service method - is used to retrieve all movies
        /// </summary>
        /// <param name="searchCriteria"></param>
        /// <returns></returns>
        Task<List<MovieGridResponse>> GetAllMovies(SearchRequest searchCriteria);

        /// <summary>
        /// This service method - is used to retrieve movie details by movie Id 
        /// </summary>
        /// <param name="movieId"></param>
        /// <returns></returns>
        Task<MovieResponse> GetMovieDetailsById(int movieId);

        /// <summary>
        /// This service method - is used to retrieve movie languages
        /// </summary>
        /// <returns></returns>
        Task<List<string>> GetAllMovieLanguages();

        /// <summary>
        /// This service method - is used to retrieve movie locations
        /// </summary>
        /// <returns></returns>
        Task<List<string>> GetAllMovieLocations();
    }
}
