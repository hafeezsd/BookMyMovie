﻿namespace BookMyMovie.Contracts
{
    public class SearchRequest
    {
        public string SearchString { get; set; }
        public string Language { get; set; }
        public string Location { get; set; }
    }
}
