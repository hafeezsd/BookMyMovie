﻿using BookMyMovie.Contracts;
using BookMyMovie.DA;
using BookMyMovie.DAInterface;
using BookMyMovie.Models;
using BookMyMovie.Service;
using BookMyMovie.ServiceInterface;
using Microsoft.Extensions.DependencyInjection;
using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace BookMyMovie.NUnitTest
{
    public class BookMyMovieTests
    {
        private readonly IServiceProvider serviceProvider;
        private readonly IBookMyMovieService _bookMyMovieService;
        private readonly IBookMyMovieRepository _bookMyMovieRepository;

        public BookMyMovieTests()
        {
            var services = new ServiceCollection();
            services.AddScoped<IBookMyMovieService, BookMyMovieService>();
            services.AddScoped<IBookMyMovieRepository, BookMyMovieRepository>();

            serviceProvider = services.BuildServiceProvider();

            _bookMyMovieService = serviceProvider.GetService<IBookMyMovieService>();

            _bookMyMovieRepository = serviceProvider.GetService<IBookMyMovieRepository>();
        }

        /// <summary>
        /// This test method - is used to test the GetMovieDetailsById method of BookMyMovieService
        /// </summary>
        /// <returns></returns>
        [Test]
        public async Task CheckGetMovieDetailsById()
        {
            Assert.IsNotNull(await _bookMyMovieService.GetMovieDetailsById(1));
        }

        /// <summary>
        /// This test method - is used to test the GetMovieLanguages method of BookMyMovieService
        /// </summary>
        /// <returns></returns>
        [Test]
        public async Task CheckGetMovieLanguages()
        {
            Assert.IsNotNull(await _bookMyMovieService.GetAllMovieLanguages());
        }

        /// <summary>
        /// This test method - is used to test the GetMovieLocations method of BookMyMovieService
        /// </summary>
        /// <returns></returns>
        [Test]
        public async Task CheckGetMovieLocations()
        {
            Assert.IsNotNull(await _bookMyMovieService.GetAllMovieLocations());
        }

        /// <summary>
        /// This test method - is used to test the GetAllMovies method of BookMyMovieService
        /// </summary>
        /// <returns></returns>
        [Test]
        public async Task CheckGetAllMovies()
        {
            SearchRequest request = new SearchRequest()
            {
                SearchString = string.Empty,
                Language = string.Empty,
                Location = string.Empty
            };

            Assert.IsNotNull(await _bookMyMovieService.GetAllMovies(request));
        }
    }
}
