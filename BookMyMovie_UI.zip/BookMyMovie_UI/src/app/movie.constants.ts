export const movieUrl = {
    getAllMovies: 'GetAllMovies',  
    getMovieDetailsById : 'GetMovieDetailsById',
    getAllMovieLanguages : 'GetAllMovieLanguages',
    getAllMovieLocations : 'GetAllMovieLocations'
  };