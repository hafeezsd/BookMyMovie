import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { MovieModel } from 'src/app/models/movie.model';
import { MovieService } from 'src/app/services/movie.service';

@Component({
  selector: 'app-movie-details',
  templateUrl: './movie-details.component.html',
  styleUrls: ['./movie-details.component.css']
})
export class MovieDetailsComponent implements OnInit {

  movieId : number;
  movie : MovieModel;

  constructor(private movieService : MovieService,private route: ActivatedRoute) { }

  ngOnInit(): void {

    this.route.paramMap.subscribe((paramMap: any) => {
      if (paramMap && paramMap.params) {
        this.movieId = paramMap.params.movieId;        
        this.getMovieDetailsById(this.movieId)
      }
    });

    
  }

  getMovieDetailsById(movieId : number)
  {
    this.movieService.getMovieDetailsById(movieId).subscribe(
      (response) =>{
        this.movie = response});
  }

  bookNow()
  {
    alert("Your booking is successful.")
  }
}
