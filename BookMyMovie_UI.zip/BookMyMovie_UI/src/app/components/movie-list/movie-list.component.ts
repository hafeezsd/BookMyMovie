import { Component, OnInit } from '@angular/core';
import { MovieModel } from '../../models/movie.model';
import { MovieService } from '../../services/movie.service';
import { Router, ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-movie-list',
  templateUrl: './movie-list.component.html',
  styleUrls: ['./movie-list.component.css']
})
export class MovieListComponent implements OnInit {

movieId : number;
movies : MovieModel[];
languages : string[];
locations : string[];
searchString : string;
languageSelected : string = "";
locationSelected : string = "";
obj : any = {
  searchString : "",
  language : "",
  location : ""
}

  constructor(private movieService : MovieService,private route: ActivatedRoute,
  private  router: Router) { }

  ngOnInit(): void {
     this.movieService.getAllMovies(this.obj).subscribe(
          (response) =>{
            this.movies = response});

      this.movieService.getAllLanguages().subscribe(
          (response) =>{
            this.languages = response});
            
      this.movieService.getAllMovieLocations().subscribe(
          (response) =>{
            this.locations = response});
  }

  filterByLanguage(language: string)
  {
    this.obj = {
      searchString : this.searchString,
      language : this.languageSelected,
      location : this.locationSelected
    }
    console.log(this.obj);
    if(language)
    {
      this.movieService.getAllMovies(this.obj).subscribe(
        (response) =>{        
          this.movies = response.filter(x => x.language.toLowerCase() == language.toLowerCase())});
    }   
    else
    {
      this.movieService.getAllMovies(this.obj).subscribe(
        (response) =>{
          this.movies = response});     
    } 
  }

  filterByLocation(location: string)
  {
    this.obj = {
      searchString : this.searchString,
      language : this.languageSelected,
      location : this.locationSelected
    }

    console.log(this.obj);
    if(location)
    {
      this.movieService.getAllMovies(this.obj).subscribe(
        (response) =>{        
          this.movies = response.filter(x => x.location.toLowerCase() == location.toLowerCase())});
    }   
    else
    {
      this.movieService.getAllMovies(this.obj).subscribe(
        (response) =>{
          this.movies = response});     
    } 
  }

  getMovieDetails(movieId : number)
  {
    console.log(movieId);
    this.router.navigate([`details/${(movieId)}`]);
  }

  search()
  {
    this.obj = {
      searchString : this.searchString,
      language : this.languageSelected,
      location : this.locationSelected
    }
    console.log(this.obj);
    this.movieService.getAllMovies(this.obj).subscribe(
      (response) =>{        
        this.movies = response});
  }
}
