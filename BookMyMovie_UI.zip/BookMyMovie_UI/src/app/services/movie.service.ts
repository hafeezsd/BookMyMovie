import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { environment } from '../../environments/environment';
import { movieUrl } from '../movie.constants'
import { MovieModel } from '../models/movie.model';
import { Observable } from 'rxjs';


@Injectable({
  providedIn: 'root'
})
export class MovieService {
  
  //obj : any;
   
  constructor(private http: HttpClient) { }

  getAllMovies(obj : any) : Observable<MovieModel[]> {
    const headers = new HttpHeaders({
      'Access-Control-Allow-Origin': '*',
  
    });
    return this.http.post<MovieModel[]>(`${environment.apiUrl}${movieUrl.getAllMovies}`,obj, {headers});
  }

  getMovieDetailsById(movieId) {
    console.log(movieId);
    return this.http.get<MovieModel>(`${environment.apiUrl}${movieUrl.getMovieDetailsById}` + '/' + movieId);
  }

  getAllLanguages() : Observable<string[]> {
    const headers = new HttpHeaders({
      'Access-Control-Allow-Origin': '*',
  
    });
    return this.http.get<string[]>(`${environment.apiUrl}${movieUrl.getAllMovieLanguages}`, {headers});
  }

  getAllMovieLocations() : Observable<string[]> {
    const headers = new HttpHeaders({
      'Access-Control-Allow-Origin': '*',
  
    });
    return this.http.get<string[]>(`${environment.apiUrl}${movieUrl.getAllMovieLocations}`, {headers});
  }
}
